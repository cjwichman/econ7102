# ECON 7102 — Environmental Economics I

Course website for ECON 7102 at Georgia Tech, Fall 2026. Built with Quarto and
served from GitHub Pages.

## How it fits together

`data/schedule.yml` is the single source of truth. It holds the meeting
calendar, topics, and every reading with its citation, link, and archive path.
Everything else is generated from it:

```
data/schedule.yml
      |
      +-- build/build.R ----> _generated/schedule.md        (site)
                              _generated/readings.md        (site)
                              _generated/tex/schedule_table.tex   (syllabus)
                              _generated/tex/reading_list.tex     (syllabus)
                              _generated/readings_manifest.tsv
                              readings/*.pdf                (copied from the
                                                             readings archive)
```

Do not edit anything in `_generated/`. Edit `data/schedule.yml` and rebuild.

## Rebuilding after a schedule change

Source `build/build.R` in R, then click Render. From a shell that is:

```bash
Rscript build/build.R
quarto render
```

`quarto render` writes to `docs/`, which is what GitHub Pages serves. The
build script reads `READINGS_ARCHIVE`, set near the top of the file, to find
the reading PDFs.

## Syllabus integration

`econ7102_fall2026_public.tex` lives in the sibling `syllabus/` directory and
pulls three files from here:

```latex
\input{../website/tex/assignments.tex}                  % hand-maintained
\input{../website/_generated/tex/schedule_table.tex}    % generated
\input{../website/_generated/tex/reading_list.tex}      % generated
```

The website and the syllabus therefore show the same schedule and reading list
by construction. Assignment descriptions are maintained in two places, since
the site version uses HTML badges and the syllabus version does not.

## Setup

See [SETUP.md](SETUP.md) for a step-by-step walkthrough: installing Quarto,
moving the project out of Dropbox, the first push, turning on GitHub Pages,
and the routine for updating the site during the semester.

Requirements: [Quarto](https://quarto.org) 1.4 or later, and R with the `yaml`
package.

`robots.txt` disallows crawling of `/readings/` and blocks the common AI
crawlers. That is a request, not enforcement.

## Files

| Path | Purpose |
|:--|:--|
| `data/schedule.yml` | Schedule and reading list. The only file to edit. |
| `build/build.R` | Generates site includes and LaTeX fragments, and stages reading PDFs. |
| `tex/assignments.tex` | Assignment descriptions for the syllabus. Hand-maintained. |
| `index.qmd` | Course overview and grading. |
| `schedule.qmd` | Schedule table. |
| `readings.qmd` | Reading list by class. |
| `assignments.qmd` | Assignment descriptions and policies. |
| `styles.scss` | Site styling. |
| `docs/` | Rendered site. Committed, served by Pages. |
