# Setting up the site

No terminal required. Everything runs from R, the Render button, and GitHub
Desktop.

---

## What the R script is for

Quarto renders `.qmd` files to HTML. It does not, on its own, know anything
about your schedule. `build/build.R` is what turns `data/schedule.yml` into
the markdown the site displays and the LaTeX the syllabus reads, and what
copies the assigned reading PDFs into `readings/`.

The split exists so the website and the syllabus cannot disagree. If the
schedule lived only in the `.qmd` files, you would maintain the reading list
twice.

Day to day:

- Changed `data/schedule.yml`? Source `build/build.R`, then render.
- Changed prose in a `.qmd`? Just render. No R needed.

---

## Step 1 — Install the tools

You already have R and VS Code. Three additions.

**Quarto CLI.** Download the macOS installer from
<https://quarto.org/docs/get-started/> and run it.

**GitHub Desktop.** <https://desktop.github.com>. Sign in with your GitHub
account. This handles every git operation with buttons.

**The R `yaml` package.** In the R console:

```r
install.packages("yaml")
```

**VS Code extension.** Extensions panel, install *Quarto* (by Posit). This
gives you the Render and Preview buttons.

---

## Step 2 — Copy the project out of Dropbox

Git and Dropbox both want to manage the same directory and corrupt each
other's state. Keep the Dropbox copy as your archive, work in a separate
folder.

In Finder: copy `Dropbox/_teaching/FALL2026/ECON7102/website` into
`Documents/Github/`, then rename the copy to `econ7102`.

---

## Step 3 — Point the build script at your readings

Open `build/build.R`. Near the top:

```r
READINGS_ARCHIVE <- "~/Dropbox/_teaching/FALL2026/ECON7102/readings"
```

That should already be correct. Change it if your Dropbox lives elsewhere.

---

## Step 4 — Run the build

Open `build/build.R` in VS Code or RStudio and source it.

- **RStudio:** the Source button, or Cmd-Shift-S.
- **VS Code:** with the R extension, Cmd-Shift-S. Without it, open an R
  console and run
  `setwd("~/Documents/Github/econ7102"); source("build/build.R")`.

Either way the working directory has to be the project root. The script stops
with a clear message if it isn't.

You should see something like:

```
Meetings: 31 (28 class sessions, 3 non-meeting days)
Readings with PDFs: 42
Readings staged in readings/: 42 copied, 0 unchanged, 0 removed
```

Reruns only copy what changed, so this is fast after the first time.

---

## Step 5 — Render the site

Open `index.qmd` in VS Code and click **Render** in the top right. Or click
**Preview** for a live browser view that refreshes on save.

This writes the finished site to `docs/`.

---

## Step 6 — Publish it

In **GitHub Desktop**:

1. **File → Add Local Repository**, choose `~/Documents/Github/econ7102`.
   It will say the folder is not a git repository and offer to **create a
   repository** here. Take that.
2. Name it `econ7102`. Leave the git ignore and license fields alone, the
   folder already has a `.gitignore`.
3. Click **Publish repository**. Uncheck *Keep this code private*.

The first publish is around 130 MB because of the reading PDFs, so give it a
few minutes.

---

## Step 7 — Turn on GitHub Pages

On github.com, in the `econ7102` repository:

**Settings → Pages → Build and deployment → Source: Deploy from a branch**

Set the branch to `main` and the folder to `/docs`. Save.

Wait a minute or two, then load <https://cjwichman.github.io/econ7102/>.

If you get a 404, confirm `docs/index.html` exists in the repository and that
`.nojekyll` is present at the repository root. That file stops GitHub from
running Jekyll, which would otherwise strip the `_generated` directory.

---

## The routine, once it is running

1. Edit `data/schedule.yml`.
2. Source `build/build.R`.
3. Click **Render**.
4. In GitHub Desktop: type a summary, **Commit to main**, then **Push origin**.

The live site updates about a minute after the push. Adding or removing a
reading needs no extra step. The build script stages new PDFs and deletes
staged ones that are no longer assigned.

---

## Rebuilding the syllabus PDF

The syllabus lives outside this repository, at
`_teaching/FALL2026/ECON7102/syllabus/econ7102_fall2026_public.tex`. It reads
three files from the website folder:

```latex
\input{../website/tex/assignments.tex}                  % hand-maintained
\input{../website/_generated/tex/schedule_table.tex}    % generated
\input{../website/_generated/tex/reading_list.tex}      % generated
```

Those relative paths assume the Dropbox layout, with `syllabus/` and
`website/` as siblings. So the Dropbox copy needs the current `_generated/`
files before you compile the syllabus.

The simple version: after sourcing `build/build.R`, copy the `_generated`
folder from `Documents/Github/econ7102/` over the one in
`Dropbox/_teaching/FALL2026/ECON7102/website/`. Then compile the `.tex` as
usual.

---

## Troubleshooting

**"Cannot find data/schedule.yml."** R's working directory is somewhere else.
Run `setwd("~/Documents/Github/econ7102")` first.

**Render fails on `{{< include >}}`.** The `_generated/` files are missing.
Source `build/build.R` first.

**"Skipped PDF staging: archive not found."** `READINGS_ARCHIVE` at the top of
`build/build.R` points somewhere that does not exist.

**A reading link 404s on the live site.** Check the build output for a
`Missing from the archive:` list. The `source_pdf` path in `schedule.yml` does
not match a real file.

**Push rejected, file too large.** GitHub blocks single files over 100 MB.
Nothing in the current set is close, but if you add a large scan, compress it
in Preview (File → Export, Quartz filter: Reduce File Size) before adding it
to the archive.
